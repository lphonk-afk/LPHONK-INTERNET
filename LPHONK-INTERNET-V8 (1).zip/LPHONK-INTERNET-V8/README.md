# LPHONK Browser V8

A mobile-friendly browser-style launchpad. It offers search providers (Google, Bing, DuckDuckGo, Brave, Startpage, Ecosia and Yahoo), direct website navigation, shortcuts, bookmarks, recent searches and local JSON backup/restore.

## Install on GitHub Pages
Upload the files in this folder to the repository root (same folder as `index.html`) and commit to the Pages branch. Keep the exact filenames.

## Important limitation
LPHONK Browser is a web launchpad, not a standalone browser engine like Chrome or Firefox. It cannot render arbitrary third-party sites inside itself because many websites block embedding. Search results and websites open in the device's browser, in a new tab or the current tab using GO.

## Privacy and safety
No analytics or ad scripts are included. Shortcuts and history are stored in this browser's local storage. The app is not an antivirus, VPN, password manager or phishing detector. Never store passwords or banking codes here.
