# LPHONK Browser Android starter

This is the Android app source project (not a compiled APK yet).

## Build
1. Install Android Studio on a computer.
2. Open this `android` folder as a project.
3. Let Gradle sync. Use JDK 17 and Android SDK 35. The project uses Jetpack Compose and AndroidX Activity Compose.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Test navigation, tabs, bookmarks, and downloads on a real Android device.

## Included in this starter
- WebView-based browser shell
- Search/address bar (Google search fallback)
- Multiple tab controls
- Local bookmarks (SharedPreferences)
- DownloadManager integration
- Private-session toggle (clears cookies/cache when enabled)

## Limitations to test before release
This is a starter implementation, not a production-hardened browser. Private mode needs security review and tests; some sites may block WebView or require external browser handling. Android WebView does not provide all Chrome features. A real release should add safe-browsing checks, better tab lifecycle/state, file chooser support, download filename/MIME handling, cookie isolation using a dedicated profile, and accessibility testing.
