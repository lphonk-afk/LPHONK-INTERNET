package com.lphonk.browser

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import org.json.JSONArray
import java.net.URLEncoder

private val Bg = Color(0xFF08090D)
private val Panel = Color(0xFF171A23)
private val Purple = Color(0xFFBD8CFF)
private val Gold = Color(0xFFE6A64D)

data class BrowserTab(val id: Int, var url: String, var title: String = "New tab")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LPHONKBrowser() }
    }
}

@Composable
fun LPHONKBrowser() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("lphonk_browser", Context.MODE_PRIVATE) }
    var tabs by remember { mutableStateOf(listOf(BrowserTab(1, "https://www.google.com"))) }
    var activeId by remember { mutableIntStateOf(1) }
    var address by remember { mutableStateOf("") }
    var privateMode by remember { mutableStateOf(false) }
    var showBookmarks by remember { mutableStateOf(false) }
    var bookmarks by remember { mutableStateOf(prefs.getStringSet("bookmarks", emptySet())?.toList() ?: emptyList()) }
    val active = tabs.firstOrNull { it.id == activeId } ?: tabs.first()
    var webView by remember { mutableStateOf<WebView?>(null) }

    fun navigate(raw: String) {
        val value = raw.trim()
        if (value.isEmpty()) return
        val target = when {
            value.startsWith("https://") || value.startsWith("http://") -> value
            value.contains('.') && !value.contains(' ') -> "https://$value"
            else -> "https://www.google.com/search?q=" + URLEncoder.encode(value, "UTF-8")
        }
        if (!target.startsWith("https://") && !target.startsWith("http://")) return
        tabs = tabs.map { if (it.id == activeId) it.copy(url = target, title = target) else it }
        address = target
        webView?.loadUrl(target)
        showBookmarks = false
    }

    fun addTab() {
        val next = (tabs.maxOfOrNull { it.id } ?: 0) + 1
        tabs = tabs + BrowserTab(next, "https://www.google.com")
        activeId = next
        address = ""
        webView?.loadUrl("https://www.google.com")
    }

    fun toggleBookmark() {
        val current = active.url
        bookmarks = if (bookmarks.contains(current)) bookmarks - current else bookmarks + current
        prefs.edit().putStringSet("bookmarks", bookmarks.toSet()).apply()
        Toast.makeText(context, "Bookmark updated", Toast.LENGTH_SHORT).show()
    }

    Column(Modifier.fillMaxSize().background(Bg).padding(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("LP", color = Purple, fontSize = 27.sp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("LPHONK BROWSER", color = Color.White, fontSize = 16.sp)
                Text(if (privateMode) "PRIVATE SESSION" else "YOUR WEB, YOUR WAY", color = Gold, fontSize = 10.sp)
            }
            TextButton(onClick = { privateMode = !privateMode; if (privateMode) { CookieManager.getInstance().removeAllCookies(null); webView?.clearHistory(); webView?.clearCache(true) } }) {
                Text(if (privateMode) "PRIVATE ON" else "PRIVATE OFF", color = if (privateMode) Gold else Purple)
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = address, onValueChange = { address = it }, modifier = Modifier.weight(1f),
                singleLine = true, placeholder = { Text("Search or enter website") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { navigate(address) }),
                colors = TextFieldDefaults.outlinedTextFieldColors(textColor = Color.White, focusedBorderColor = Purple, unfocusedBorderColor = Panel)
            )
            Spacer(Modifier.width(6.dp))
            Button(onClick = { navigate(address) }, colors = ButtonDefaults.buttonColors(backgroundColor = Purple)) { Text("GO", color = Bg) }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
            tabs.forEach { tab ->
                TextButton(onClick = { activeId = tab.id; address = tab.url; webView?.loadUrl(tab.url) }) {
                    Text("Tab ${tab.id}", color = if (tab.id == activeId) Gold else Color.LightGray)
                }
            }
            TextButton(onClick = { addTab() }) { Text("+", color = Purple, fontSize = 22.sp) }
            TextButton(onClick = { toggleBookmark() }) { Text("★", color = Gold, fontSize = 20.sp) }
            TextButton(onClick = { showBookmarks = !showBookmarks }) { Text("Saved", color = Purple) }
        }
        if (showBookmarks) {
            Text("BOOKMARKS", color = Gold, modifier = Modifier.padding(8.dp))
            LazyColumn {
                items(bookmarks) { item ->
                    TextButton(onClick = { navigate(item) }) { Text(item, color = Color.White) }
                }
            }
        } else {
            key(activeId, privateMode) {
                AndroidView(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.loadsImagesAutomatically = true
                            settings.setSupportMultipleWindows(false)
                            if (privateMode) {
                                settings.cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
                                clearCache(true)
                                CookieManager.getInstance().setAcceptCookie(false)
                            } else {
                                settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
                                CookieManager.getInstance().setAcceptCookie(true)
                            }
                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    url?.let { address = it; tabs = tabs.map { t -> if (t.id == activeId) t.copy(url = it, title = it) else t } }
                                }
                            }
                            webChromeClient = WebChromeClient()
                            setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                                try {
                                    val request = DownloadManager.Request(Uri.parse(url))
                                        .setMimeType(mimeType)
                                        .addRequestHeader("User-Agent", userAgent)
                                        .setTitle("LPHONK download")
                                        .setDescription("Downloading file")
                                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "LPHONK-" + System.currentTimeMillis())
                                    (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                                    Toast.makeText(ctx, "Download started", Toast.LENGTH_SHORT).show()
                                } catch (_: Exception) { Toast.makeText(ctx, "Download failed", Toast.LENGTH_SHORT).show() }
                            })
                            loadUrl(active.url)
                            webView = this
                        }
                    },
                    update = { view -> if (view.url != active.url) view.loadUrl(active.url); webView = view }
                )
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = { webView?.goBack() }) { Text("← Back", color = Color.White) }
            TextButton(onClick = { webView?.reload() }) { Text("↻ Reload", color = Color.White) }
            TextButton(onClick = { if (tabs.size > 1) { tabs = tabs.filterNot { it.id == activeId }; activeId = tabs.last().id; address = tabs.last().url } else addTab() } ) { Text("Close tab", color = Gold) }
            TextButton(onClick = { webView?.goForward() }) { Text("Forward →", color = Color.White) }
        }
    }
}
