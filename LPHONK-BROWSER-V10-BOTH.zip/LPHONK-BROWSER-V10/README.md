# LPHONK Browser V10 — both editions

- `web/` is the GitHub Pages start-page edition.
- `android/` is the Android Studio source project for the standalone WebView app.

The web edition can open sites and search using the user's installed browser. It cannot fully control browser tabs or Android downloads. The Android source includes tab controls, local bookmarks, DownloadManager, and a private-session starter toggle.

No APK is included: APK must be built and tested in Android Studio.
