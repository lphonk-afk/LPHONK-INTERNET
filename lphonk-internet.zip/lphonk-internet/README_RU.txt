# LPHONK INTERNET — Version 1

A free, static web portal that works on phones and computers.

## Run it on your computer
1. Extract `lphonk-internet.zip`.
2. Open the `lphonk-internet` folder.
3. Double-click `index.html`.
4. Your browser opens the site. Search uses Google; quick links open their official websites.

## Publish it free with GitHub Pages
1. Create/sign in to a GitHub account at https://github.com/.
2. Create a new **public** repository named `lphonk-internet`.
3. Upload `index.html` from this folder to the repository root.
4. Open repository **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then press **Save**.
7. Wait for GitHub Pages to publish. Your site address will appear in the Pages section.

## Important
- No payment or domain is required for the first version.
- A free GitHub Pages address is usually `https://YOUR-USERNAME.github.io/lphonk-internet/`.
- This is a portal/website, not a new global internet network, browser engine, search index, or internet provider.
- Never upload passwords, API keys, or private information to a public repository.
