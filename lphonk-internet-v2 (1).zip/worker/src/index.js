const enc = new TextEncoder();
const MAX_BODY = 64 * 1024, MAX_BM = 200, LIMIT = 60;

async function sha(s) {
  const d = await crypto.subtle.digest("SHA-256", enc.encode(s));
  return [...new Uint8Array(d)].map(b => b.toString(16).padStart(2, "0")).join("");
}
const isHttps = u => { try { const x = new URL(u); return x.protocol === "https:" && !x.username && !x.password; } catch { return false; } };

export default {
  async fetch(req, env) {
    const cors = {
      "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN,
      "Access-Control-Allow-Methods": "GET,PUT,OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type,X-Sync-Key",
      "Vary": "Origin",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    };
    const out = (obj, status = 200) =>
      new Response(JSON.stringify(obj), { status, headers: { ...cors, "Content-Type": "application/json" } });

    if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
    const url = new URL(req.url);
    if (url.pathname === "/api/health") return out({ ok: true });
    if (url.pathname !== "/api/sync") return out({ error: "not_found" }, 404);

    // Rate limit: IP is stored only as a hash, per-minute window
    const win = Math.floor(Date.now() / 60000);
    const iph = await sha(req.headers.get("CF-Connecting-IP") || "unknown");
    await env.DB.prepare("INSERT INTO rate (ip,win,n) VALUES (?,?,1) ON CONFLICT(ip,win) DO UPDATE SET n=n+1").bind(iph, win).run();
    const row = await env.DB.prepare("SELECT n FROM rate WHERE ip=? AND win=?").bind(iph, win).first();
    if (row && row.n > LIMIT) return out({ error: "rate_limited" }, 429);
    if (Math.random() < 0.02) await env.DB.prepare("DELETE FROM rate WHERE win < ?").bind(win - 10).run();

    // Anonymous profile: id = SHA-256 of a random key held only by the user
    const key = req.headers.get("X-Sync-Key") || "";
    if (!/^[a-f0-9]{64}$/.test(key)) return out({ error: "bad_key" }, 401);
    const id = await sha(key);

    if (req.method === "GET") {
      const r = await env.DB.prepare("SELECT data FROM profiles WHERE id=?").bind(id).first();
      return r ? out(JSON.parse(r.data)) : out({ error: "no_profile" }, 404);
    }
    if (req.method === "PUT") {
      const text = await req.text();
      if (text.length > MAX_BODY) return out({ error: "too_large" }, 413);
      let body; try { body = JSON.parse(text); } catch { return out({ error: "bad_json" }, 400); }
      if (!Array.isArray(body.bookmarks) || body.bookmarks.length > MAX_BM) return out({ error: "bad_bookmarks" }, 400);
      const bookmarks = body.bookmarks
        .filter(b => b && typeof b.t === "string" && typeof b.u === "string" && isHttps(b.u))
        .map(b => ({ t: b.t.slice(0, 100), u: b.u.slice(0, 2000) }));
      await env.DB.prepare("INSERT INTO profiles (id,data,updated_at) VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data, updated_at=excluded.updated_at")
        .bind(id, JSON.stringify({ bookmarks }), Date.now()).run();
      return out({ ok: true, count: bookmarks.length });
    }
    return out({ error: "method_not_allowed" }, 405);
  },
};
