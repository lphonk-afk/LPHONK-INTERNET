# LPHONK INTERNET V2

## 1. Сервер (Cloudflare)
```
cd worker
npm i -g wrangler && wrangler login
wrangler d1 create lphonk-internet        # скопируйте database_id в wrangler.toml
wrangler d1 execute lphonk-internet --remote --file=schema.sql
# в wrangler.toml origin уже указан: lphonk-afk.github.io
wrangler deploy                            # получите https://lphonk-internet-api.<you>.workers.dev
```
Проверка: открыть `<адрес>/api/health` — должно вернуть {"ok":true}.

## 2. Сайт (GitHub Pages)
Загрузите `index.html` в репозиторий `lphonk-afk.github.io` или включите Pages для репозитория.

## 3. Синхронизация
На сайте, блок «Синхронизация»: вставьте адрес Worker, нажмите «Создать ключ», затем «Синхронизировать».
На другом устройстве введите тот же адрес и ключ. Ключ храните как пароль: потеряли — доступ не восстановить.

## Приватность
Сервер хранит только закладки и хэш ключа. История поиска, запросы, пароли и e-mail на сервер не отправляются. IP хранится только в виде хэша для лимита запросов (60/мин).
Слияние закладок объединяющее: удаление на одном устройстве само на другое не переносится.
