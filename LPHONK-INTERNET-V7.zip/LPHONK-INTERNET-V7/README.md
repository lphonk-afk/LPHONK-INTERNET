# LPHONK INTERNET V7

Responsive personal web launchpad for Android and desktop.

## Features
- Search via Google, Bing, DuckDuckGo or Brave.
- Quick Access shortcuts, custom links and bookmarks.
- Recent search history (up to 80 entries).
- JSON backup and validated restore (1 MB maximum).
- Local-only preferences and data; no analytics, advertising pixels or third-party scripts.
- HTTPS-first shortcut validation; external links open with `noopener noreferrer`.
- Basic PWA shell caching for repeat visits.
- Privacy-oriented browser policy headers in the HTML document.

## Safety and limitations
This is a launchpad, not an antivirus, VPN, firewall, password manager or phishing detector. It cannot guarantee that external sites are safe. Search terms are sent to the selected search provider. Bookmarks and history are stored in the browser's local storage and are not encrypted or synced. Anyone with access to this browser profile may be able to view them. Do not store passwords, bank details or other secrets here.

## Publish on GitHub Pages
1. Upload `index.html`, `manifest.webmanifest`, `icon.svg`, `sw.js`, and `README.md` to the repository root.
2. Keep the main page filename exactly `index.html`.
3. In Settings → Pages, choose Deploy from a branch → `main` → `/(root)`.
4. Wait for the Pages deployment action to finish, then open the Pages URL.

No build step is required.
