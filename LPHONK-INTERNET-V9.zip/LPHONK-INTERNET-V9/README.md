# LPHONK INTERNET V9

LPHONK Browser is a browser-style start page, not a standalone browser engine.
It opens websites and search results in the browser already installed on your device.

## Included search providers
Google, Bing, DuckDuckGo, Brave Search, Startpage, Ecosia, Yahoo, Qwant, Google Scholar.

## Install / update on GitHub Pages
1. Open the repository `lphonk-afk/LPHONK-INTERNET`.
2. Upload the contents of this folder to the repository root.
3. Replace the existing `index.html`, `manifest.webmanifest`, `icon.svg`, and `sw.js`.
4. Commit the changes, then open the GitHub Pages website and refresh it.

Keep all four files together in the repository root. Uploading the ZIP itself does not publish the website; extract it first.
