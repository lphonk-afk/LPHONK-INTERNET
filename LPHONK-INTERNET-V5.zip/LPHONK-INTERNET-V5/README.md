# LPHONK INTERNET V5

A responsive personal web portal with web search shortcuts, quick-access sites, local bookmarks/history, JSON backup/restore, and an installable PWA shell.

## Publish on GitHub Pages
1. Upload `index.html`, `manifest.webmanifest`, and `sw.js` to the root of the `LPHONK-INTERNET` repository's `main` branch.
2. In GitHub, open **Settings → Pages**.
3. Set **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
4. Wait for deployment and open `https://lphonk-afk.github.io/LPHONK-INTERNET/` over HTTPS.

## Features and limits
- Search providers: Google, Bing, DuckDuckGo, Brave.
- Add/remove quick-access websites (right-click or long-press context menu where supported).
- Search history and bookmarks are stored in this browser's local storage.
- Export/import JSON backup.
- Service worker caches the app shell for repeat/offline opening after first successful load.
- This is a portal, not a full browser. Search is redirected to the selected provider. No user accounts or cloud sync are included; those require a backend and secure authentication.
