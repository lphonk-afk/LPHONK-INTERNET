# LPHONK INTERNET V6

A responsive personal web launchpad with multi-provider search, quick-access sites, bookmarks, local search history, backup/restore, language preferences (English/Russian/Kazakh), accent color settings, keyboard shortcut, and installable PWA shell.

## Publish on GitHub Pages
1. Upload **all four files** (`index.html`, `manifest.webmanifest`, `sw.js`, `icon.svg`) to the root of `lphonk-afk/LPHONK-INTERNET` on the `main` branch.
2. In GitHub open **Settings → Pages**.
3. Choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. After deployment, open https://lphonk-afk.github.io/LPHONK-INTERNET/ .

## Features
- Google, Bing, DuckDuckGo and Brave search.
- Add and remove quick-access websites.
- Bookmark quick-access websites; view and remove bookmarks.
- Recent search history (up to 80 entries).
- Export/import JSON backup.
- English, Russian and Kazakh interface options.
- Four accent color choices.
- PWA manifest, SVG app icon and offline app-shell cache.
- `/` focuses search; `Esc` closes dialogs.

## Privacy and limitations
Data is stored in this browser's local storage. It is not synced between devices. Search requests are sent to the selected search provider. This is a web portal/launchpad, not a full browser; it does not provide private browsing, a proxy, user accounts, cloud sync, or its own search index. PWA installation and service-worker caching require HTTPS (GitHub Pages provides HTTPS).
